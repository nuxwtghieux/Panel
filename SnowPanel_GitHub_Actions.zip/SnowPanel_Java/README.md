# SNOW PANEL - Android project

## Cau hinh
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17 tro len
- compileSdk: 35
- minSdk: 23

## Build trong AndroidIDE
1. Giai nen toan bo thu muc `SnowPanel_Java`.
2. Mo thu muc goc co `settings.gradle` va `gradlew` trong AndroidIDE.
3. Chon JDK 17 tro len trong cai dat Gradle/JDK cua AndroidIDE.
4. Mo Terminal tai thu muc project, chay: `chmod +x gradlew && ./gradlew assembleDebug`
5. APK neu build thanh cong nam tai `app/build/outputs/apk/debug/app-debug.apk`.

`gradlew` trong goi nay la script bootstrap: lan dau no tu tai Gradle 8.9 bang curl/wget, khong can `gradle-wrapper.jar`. Can ket noi mang trong lan dau build. Neu AndroidIDE khong co curl/wget/unzip hoac khong tai duoc, hay dung Gradle 8.9 da cai san va chay `gradle assembleDebug`.

Luu y: AGP 8.7.3 khong chay voi Java 8 / Gradle 6.1.1. Can JDK 17+ va Gradle 8.9. Day la giao dien mau SNOW PANEL; cac nut chuc nang hien tai la man hinh minh hoa, chua ket noi dich vu tai khoan.
