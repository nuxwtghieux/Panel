@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=8.9
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%-bin\manual
set GRADLE_BIN=%DIST_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  echo Please download and extract Gradle %GRADLE_VERSION% into %DIST_DIR%
  exit /b 1
)
java -version 2>&1 | findstr /R "version \"17\|version \"18\|version \"19\|version \"20\|version \"21\|version \"22\|version \"23" >nul
if errorlevel 1 echo Warning: Android Gradle Plugin 8.7.3 requires JDK 17 or newer.
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
endlocal
