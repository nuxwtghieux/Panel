package com.snowpanel.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFFF0F2FF);
        getWindow().setNavigationBarColor(0xFFF0F2FF);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );
        setContentView(R.layout.activity_main);
        bind(R.id.nav_home, "Trang chủ");
        bind(R.id.nav_acc, "Nuôi Acc");
        bind(R.id.nav_page, "Reg Page");
        bind(R.id.nav_share, "Share Ảo");
        bind(R.id.nav_settings, "Cấu hình");
    }
    private void bind(int id, String label) {
        View view = findViewById(id);
        view.setOnClickListener(v -> {
            if (!label.equals("Trang chủ")) {
                Toast.makeText(this, label + " – giao diện chức năng sẽ bổ sung sau", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
